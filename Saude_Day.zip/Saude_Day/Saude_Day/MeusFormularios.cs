﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saude_Day
{
    public class MeusFormularios
    {
        public static FormAddAlt FormAddAlt { get; set;}
        public static FormPrincipal FormPrincipal { get; set; }
        public static FormLista FormLista { get; set; }
        public static FormExcluir FormExcluir { get; set; }
        public static FormTomei FormTomei { get; set; }
        public static FormIMC FormIMC { get; set; }
        public static FormDica FormDica { get; set; }
        public static FormLogin FormLogin { get; set; }
    }
}
